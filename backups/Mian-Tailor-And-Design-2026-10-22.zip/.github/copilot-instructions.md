# Workspace Setup

- [x] Verify workspace instructions file.
- [x] Clarify requirements: responsive React and TypeScript storefront for Pakistani men's shalwar kameez.
- [x] Scaffold React + TypeScript with Vite.
- [x] Build 50 distinct shalwar kameez stitch designs, five colorways per design, separate route pages, and client-side shopping bag.
- [x] No extra VS Code extensions required.
- [x] Production build verified with `npm run build`.
- [x] No custom VS Code task is needed; use the npm scripts in `package.json`.
- [x] Launch the dev server after user confirmation.
- [x] Update `README.md` with current project details and run commands.

## Project Notes

- Routes: home, shop, product detail, craft, and fitting request.
- Brand: Mian Tailor And Design, with a CSS-drawn M monogram and typographic wordmark.
- Product designs combine ten silhouettes with five stitch treatments; each has five colorways.
- Product imagery is loaded from Unsplash and fonts from Google Fonts.
- Source backup: `backups/Mian-Tailor-And-Design-2026-10-22.zip`.
- Cart state is client-side and is not persisted between reloads.
- Fitting requests are demo-only; checkout and payment processing are not connected.
